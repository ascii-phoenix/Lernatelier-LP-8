﻿
using var game = new Billiards.Game1();
game.Run();
